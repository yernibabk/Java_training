package com.mnf.spring.security.web;

import javax.annotation.security.RolesAllowed;

import org.springframework.stereotype.Service;

@Service
public class UserService {

    @RolesAllowed({"ROLE_ADMIN"})
	public String met() {
		return "from meet";
	}
}
