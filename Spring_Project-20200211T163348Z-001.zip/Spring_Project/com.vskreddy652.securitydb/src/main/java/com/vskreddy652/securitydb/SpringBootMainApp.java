package com.vskreddy652.securitydb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMainApp {
public static void main(String[] args) {
SpringApplication.run(SpringBootMainApp.class, args);
}
}
