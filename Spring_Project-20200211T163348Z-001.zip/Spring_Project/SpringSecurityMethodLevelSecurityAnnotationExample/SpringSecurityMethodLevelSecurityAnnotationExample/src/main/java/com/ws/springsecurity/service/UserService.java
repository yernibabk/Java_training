package com.ws.springsecurity.service;

import java.util.List;

import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ws.springsecurity.model.User;


public interface UserService {

	List<User> findAllUsers();

	/*
	 *  the returned value from the method(User object) will be accessible with 
	 *  returnObject in Spring Expression Language, and individual properties of 
	 *  return user object can be used to apply some security rules. 
	 *  In this example we are 
	 *  making sure that a logged-in user can only get it�s own User type object.
	 */
	@PostAuthorize ("returnObject.type == authentication.name")
	User findById(int id);

	@PreAuthorize("hasRole('ADMIN')")
	void updateUser(User user);
	
	//deleteUser is now configured to be invoked by a user 
	//who have both ADMIN & DBA roles.
	@PreAuthorize("hasRole('ADMIN') AND hasRole('DBA')")
	void deleteUser(int id);
	
		
}