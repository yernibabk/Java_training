db4free.com

db: pmsqsld
username: pmsqsqq
pwd: mysqldbpwd

spring.datasource.url=jdbc:mysql://db4free.net:3306/pmsqsld?useSSL=false
spring.datasource.username=pmsqsqq
spring.datasource.password=mysqldbpwd
spring.jpa.generate-ddl=true

? -> one character
* -> zero or more char
** -> matches zero or more directories in path

@EnableglobalMethodSecurity -> security at method level

JWT -> json web token

suresh.reddy@iiht.co.in

-> print headers